import { useEffect, useState } from 'react'
import { Link } from 'react-router-dom'
import SearchBar from '../components/SearchBar'
import api from '../api/axios'

export default function PublicFeed() {
  const [articles, setArticles] = useState([])
  const [loading, setLoading]   = useState(true)
  const [error, setError]       = useState(null)
  const [search, setSearch]     = useState('')
  const [tag, setTag]           = useState('')
  const [author, setAuthor]     = useState('')
  const [date, setDate]         = useState('')
  const [debouncedFilters, setDebouncedFilters] = useState({
    search: '',
    tag: '',
    author: '',
    date: '',
  })

  useEffect(() => {
    const timer = setTimeout(() => {
      setDebouncedFilters({ search, tag, author, date })
    }, 300)

    return () => clearTimeout(timer)
  }, [search, tag, author, date])

  useEffect(() => {
    const controller = new AbortController()

    const load = async () => {
      setLoading(true)
      setError(null)
      try {
        const { data } = await api.get('/public/articles', {
          params: {
            search: debouncedFilters.search,
            tag: debouncedFilters.tag,
            author: debouncedFilters.author || undefined,
            date: debouncedFilters.date || undefined,
          },
          signal: controller.signal,
        })
        setArticles(data)
      } catch (err) {
        if (err.code !== 'ERR_CANCELED') {
          setError(err.response?.data?.message || 'Failed to load public articles')
        }
      } finally {
        setLoading(false)
      }
    }

    load()
    return () => controller.abort()
  }, [debouncedFilters])

  const allTags = [...new Set(articles.flatMap((a) => a.tags || []))]

  return (
    <div className="mx-auto max-w-5xl px-4 py-10">
      {/* Hero */}
      <div className="mb-10 text-center">
        <h1 className="text-4xl font-bold text-gray-900 mb-3">Published Articles</h1>
        <p className="text-gray-500 text-lg">Explore notes and articles shared by the community</p>
      </div>

      {/* Search & tag filter */}
      <div className="mb-6 flex flex-col sm:flex-row gap-3">
        <div className="flex-1">
          <SearchBar value={search} onChange={setSearch} placeholder="Search articles…" />
        </div>
        <input
          type="text"
          value={author}
          onChange={(e) => setAuthor(e.target.value)}
          placeholder="Filter by author…"
          className="input sm:w-56"
        />
        <input
          type="date"
          value={date}
          onChange={(e) => setDate(e.target.value)}
          className="input sm:w-44"
          aria-label="Filter by publish date"
        />
      </div>
      {allTags.length > 0 && (
        <div className="mb-6 flex flex-wrap gap-2">
          <button
            onClick={() => setTag('')}
            className={`badge px-3 py-1 text-xs font-medium ${!tag ? 'bg-brand-600 text-white' : 'bg-gray-100 text-gray-600 hover:bg-gray-200'}`}
          >
            All
          </button>
          {allTags.map((t, index) => (
            <button
              key={`${t}-${index}`}
              onClick={() => setTag(t === tag ? '' : t)}
              className={`badge px-3 py-1 text-xs font-medium ${tag === t ? 'bg-brand-600 text-white' : 'bg-gray-100 text-gray-600 hover:bg-gray-200'}`}
            >
              #{t}
            </button>
          ))}
        </div>
      )}

      {/* Articles */}
      {error && (
        <div className="mb-4 rounded-lg border border-red-200 bg-red-50 p-3 text-sm text-red-700">
          {error}
        </div>
      )}

      {loading ? (
        <div className="grid gap-6 sm:grid-cols-2">
          {Array.from({ length: 4 }).map((_, i) => (
            <div key={i} className="card h-56 animate-pulse bg-gray-100" />
          ))}
        </div>
      ) : articles.length === 0 ? (
        <div className="py-24 text-center">
          <span className="text-5xl mb-4 block">📭</span>
          <p className="text-gray-500">No articles found.</p>
        </div>
      ) : (
        <div className="grid gap-6 sm:grid-cols-2">
          {articles.map((article) => (
            <Link key={article.id} to={`/articles/${article.id}`} className="card group hover:shadow-md transition-shadow">
              {article.coverImage && (
                <img src={article.coverImage} alt={article.title} className="h-40 w-full rounded-t-xl object-cover" />
              )}
              <div className="p-5">
                <p className="mb-1 text-xs text-gray-400">
                  By {article.author?.name} · {new Date(article.publishedAt).toLocaleDateString()}
                </p>
                <h2 className="text-base font-semibold text-gray-900 group-hover:text-brand-600 transition-colors mb-2 line-clamp-2">
                  {article.title}
                </h2>
                {article.summary && (
                  <p className="text-sm text-gray-500 line-clamp-3">{article.summary}</p>
                )}
                {article.tags?.length > 0 && (
                  <div className="mt-3 flex flex-wrap gap-1">
                    {article.tags.slice(0, 4).map((t, index) => (
                      <span key={`${t}-${index}`} className="badge bg-brand-50 text-brand-600 text-xs">#{t}</span>
                    ))}
                  </div>
                )}
              </div>
            </Link>
          ))}
        </div>
      )}
    </div>
  )
}
