package com.noteflow.dto.note;

import java.util.List;

import jakarta.validation.constraints.NotBlank;
import lombok.Data;

@Data
public class NoteRequest {

    @NotBlank
    private String title;

    private String content;

    private String summary;

    private List<String> tags;

    private String metaDescription;

    private String coverImage;

    private String status;
}
