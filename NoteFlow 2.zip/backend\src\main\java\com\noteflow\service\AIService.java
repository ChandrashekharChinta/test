package com.noteflow.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClient;

import com.noteflow.model.Note;
import com.noteflow.repository.NoteRepository;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class AIService {

    private static final Logger LOGGER = LoggerFactory.getLogger(AIService.class);

    private final NoteRepository noteRepository;
    private final WebClient webClient = WebClient.builder().build();

    @Value("${claude.api.key:}")
    private String claudeApiKey;

    @Value("${claude.api.url}")
    private String claudeApiUrl;

    @Value("${claude.model}")
    private String claudeModel;

    private static final int MAX_CHARS = 6000;

    public String generateSummary(String userId, String noteId, String content) {
        String source = contentOrNoteContent(userId, noteId, content);
        if (source.isBlank()) {
            return "";
        }

        if (!isClaudeConfigured()) {
            return fallbackSummary(source);
        }

        String prompt = "Summarize the following note in 2-3 concise sentences:\n\n" + crop(source);
        String value = callClaude(prompt).trim();
        return value.isBlank() ? fallbackSummary(source) : value;
    }

    public List<String> generateTags(String userId, String noteId, String content) {
        String source = contentOrNoteContent(userId, noteId, content);
        if (source.isBlank()) {
            return List.of();
        }

        if (!isClaudeConfigured()) {
            return fallbackTags(source);
        }

        String prompt = "Generate 5 concise tags for this note as comma-separated words only:\n\n" + crop(source);
        String raw = callClaude(prompt);
        List<String> tags = parseCommaSeparated(raw).stream().limit(8).collect(Collectors.toList());
        return tags.isEmpty() ? fallbackTags(source) : tags;
    }

    public String generateMetaDescription(String userId, String noteId, String content) {
        String source = contentOrNoteContent(userId, noteId, content);
        if (source.isBlank()) {
            return "";
        }

        if (!isClaudeConfigured()) {
            return fallbackMeta(source);
        }

        String prompt = "Write an SEO meta description under 160 characters for this note:\n\n" + crop(source);
        String value = callClaude(prompt).replace("\n", " ").trim();
        if (value.isBlank()) {
            return fallbackMeta(source);
        }
        return value.length() > 160 ? value.substring(0, 160) : value;
    }

    public List<String> suggestIdeas(String userId, String noteId, String content) {
        String source = contentOrNoteContent(userId, noteId, content);
        if (source.isBlank()) {
            return List.of();
        }

        if (!isClaudeConfigured()) {
            return fallbackIdeas(source);
        }

        String prompt = "Suggest 5 related article ideas based on this note. Return one per line:\n\n" + crop(source);
        List<String> ideas = callClaude(prompt)
                .lines()
                .map(String::trim)
                .filter(line -> !line.isBlank())
                .map(line -> line.replaceFirst("^[0-9]+[).\\s-]*", ""))
                .limit(5)
                .collect(Collectors.toList());
        return ideas.isEmpty() ? fallbackIdeas(source) : ideas;
    }

    private String contentOrNoteContent(String userId, String noteId, String content) {
        if (content != null && !content.isBlank()) {
            return stripHtml(content);
        }

        Note note = noteRepository.findByIdAndAuthorId(noteId, userId)
                .orElseThrow(() -> new IllegalArgumentException("Note not found."));
        return stripHtml(note.getContent());
    }

    private boolean isClaudeConfigured() {
        return claudeApiKey != null && !claudeApiKey.isBlank();
    }

    @SuppressWarnings("unchecked")
    private String callClaude(String prompt) {
        Map<String, Object> body = new HashMap<>();
        body.put("model", claudeModel);
        body.put("max_tokens", 400);
        body.put("messages", List.of(Map.of("role", "user", "content", prompt)));

        Map<String, Object> response;
        try {
            response = webClient.post()
                    .uri(claudeApiUrl)
                    .contentType(MediaType.APPLICATION_JSON)
                    .header("x-api-key", claudeApiKey)
                    .header("anthropic-version", "2023-06-01")
                    .bodyValue(body)
                    .retrieve()
                    .bodyToMono(Map.class)
                    .block();
        } catch (RuntimeException ex) {
            LOGGER.warn("AI provider call failed", ex);
            throw new AiProviderException("AI provider request failed", ex);
        }

        if (response == null) {
            return "";
        }

        Object contentObj = response.get("content");
        if (!(contentObj instanceof List<?> contentList) || contentList.isEmpty()) {
            return "";
        }

        Object first = contentList.get(0);
        if (!(first instanceof Map<?, ?> firstMap)) {
            return "";
        }

        Object text = firstMap.get("text");
        return text == null ? "" : text.toString();
    }

    private String stripHtml(String html) {
        if (html == null) {
            return "";
        }
        return html.replaceAll("<[^>]*>", " ")
                .replaceAll("\\s+", " ")
                .trim();
    }

    private String crop(String text) {
        if (text.length() <= MAX_CHARS) {
            return text;
        }
        return text.substring(0, MAX_CHARS);
    }

    private String fallbackSummary(String source) {
        if (source.length() <= 280) {
            return source;
        }
        return source.substring(0, 277) + "...";
    }

    private List<String> fallbackTags(String source) {
        Map<String, Integer> freq = new HashMap<>();
        for (String token : source.toLowerCase(Locale.ROOT).split("[^a-z0-9]+")) {
            if (token.length() < 4) {
                continue;
            }
            freq.put(token, freq.getOrDefault(token, 0) + 1);
        }

        return freq.entrySet().stream()
                .sorted((a, b) -> b.getValue().compareTo(a.getValue()))
                .limit(6)
                .map(Map.Entry::getKey)
                .collect(Collectors.toList());
    }

    private String fallbackMeta(String source) {
        String cleaned = source.replaceAll("\\s+", " ").trim();
        if (cleaned.length() <= 160) {
            return cleaned;
        }
        return cleaned.substring(0, 157) + "...";
    }

    private List<String> fallbackIdeas(String source) {
        List<String> tags = fallbackTags(source);
        List<String> ideas = new ArrayList<>();
        for (String tag : tags) {
            ideas.add("A practical guide to " + tag);
        }
        while (ideas.size() < 5) {
            ideas.add("Advanced tips for note-taking workflow " + (ideas.size() + 1));
        }
        return ideas.stream().limit(5).collect(Collectors.toList());
    }

    private List<String> parseCommaSeparated(String raw) {
        return List.of(raw.split(","))
                .stream()
                .map(String::trim)
                .map(value -> value.replaceAll("^#+", ""))
                .filter(value -> !value.isBlank())
                .collect(Collectors.toList());
    }
}
