package com.noteflow.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.mongodb.repository.MongoRepository;

import com.noteflow.model.Note;

public interface NoteRepository extends MongoRepository<Note, String> {

    List<Note> findByAuthorIdOrderByUpdatedAtDesc(String authorId);

    List<Note> findByAuthorIdAndStatusOrderByUpdatedAtDesc(String authorId, String status);

    Optional<Note> findByIdAndAuthorId(String id, String authorId);

    List<Note> findByStatusOrderByPublishedAtDesc(String status);

    Optional<Note> findByIdAndStatus(String id, String status);
}
