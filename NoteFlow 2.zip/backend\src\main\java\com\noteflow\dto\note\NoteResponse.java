package com.noteflow.dto.note;

import java.time.Instant;
import java.util.List;

import com.noteflow.model.Note;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class NoteResponse {

    private String id;
    private String title;
    private String content;
    private String summary;
    private List<String> tags;
    private String metaDescription;
    private String coverImage;
    private String status;
    private String authorId;
    private Instant createdAt;
    private Instant updatedAt;
    private Instant publishedAt;

    public static NoteResponse from(Note note) {
        return NoteResponse.builder()
                .id(note.getId())
                .title(note.getTitle())
                .content(note.getContent())
                .summary(note.getSummary())
                .tags(note.getTags())
                .metaDescription(note.getMetaDescription())
                .coverImage(note.getCoverImage())
                .status(note.getStatus())
                .authorId(note.getAuthorId())
                .createdAt(note.getCreatedAt())
                .updatedAt(note.getUpdatedAt())
                .publishedAt(note.getPublishedAt())
                .build();
    }
}
