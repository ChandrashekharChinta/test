package com.noteflow.controller;

import java.util.List;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.noteflow.dto.note.PublicNoteResponse;
import com.noteflow.service.NoteService;

import lombok.RequiredArgsConstructor;

@RestController
@RequestMapping("/api/public")
@RequiredArgsConstructor
public class PublicController {

    private final NoteService noteService;

    @GetMapping("/articles")
    public ResponseEntity<List<PublicNoteResponse>> getPublished(
            @RequestParam(required = false) String search,
            @RequestParam(required = false) String tag,
            @RequestParam(required = false) String author,
            @RequestParam(required = false) String date) {
        return ResponseEntity.ok(noteService.listPublic(search, tag, author, date));
    }

    @GetMapping("/articles/{id}")
    public ResponseEntity<PublicNoteResponse> getPublishedById(@PathVariable String id) {
        return ResponseEntity.ok(noteService.getPublicById(id));
    }
}
