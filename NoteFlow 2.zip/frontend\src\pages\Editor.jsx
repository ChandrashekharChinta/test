import { useEffect, useRef, useState } from 'react'
import { useNavigate, useParams } from 'react-router-dom'
import { useEditor, EditorContent } from '@tiptap/react'
import StarterKit from '@tiptap/starter-kit'
import Image from '@tiptap/extension-image'
import Link from '@tiptap/extension-link'
import CodeBlock from '@tiptap/extension-code-block'
import Placeholder from '@tiptap/extension-placeholder'
import AIPanel from '../components/AIPanel'
import { useNoteStore } from '../store/noteStore'
import api from '../api/axios'

const TOOLBAR_BUTTONS = [
  { label: 'B',   action: (e) => e.chain().focus().toggleBold().run(),       active: (e) => e.isActive('bold') },
  { label: 'I',   action: (e) => e.chain().focus().toggleItalic().run(),     active: (e) => e.isActive('italic') },
  { label: 'H1',  action: (e) => e.chain().focus().toggleHeading({ level: 1 }).run(), active: (e) => e.isActive('heading', { level: 1 }) },
  { label: 'H2',  action: (e) => e.chain().focus().toggleHeading({ level: 2 }).run(), active: (e) => e.isActive('heading', { level: 2 }) },
  { label: 'UL',  action: (e) => e.chain().focus().toggleBulletList().run(), active: (e) => e.isActive('bulletList') },
  { label: 'OL',  action: (e) => e.chain().focus().toggleOrderedList().run(),active: (e) => e.isActive('orderedList') },
  { label: '< >', action: (e) => e.chain().focus().toggleCodeBlock().run(),  active: (e) => e.isActive('codeBlock') },
  { label: '---', action: (e) => e.chain().focus().setHorizontalRule().run(), active: () => false },
]

export default function Editor() {
  const { id } = useParams()
  const isNew  = id === 'new'
  const navigate = useNavigate()

  const { fetchNote, currentNote, createNote, updateNote } = useNoteStore()

  const [title, setTitle]           = useState('')
  const [summary, setSummary]       = useState('')
  const [tags, setTags]             = useState([])
  const [tagInput, setTagInput]     = useState('')
  const [metaDesc, setMetaDesc]     = useState('')
  const [status, setStatus]         = useState('draft')
  const [coverImage, setCoverImage] = useState('')
  const [saving, setSaving]         = useState(false)
  const [saved, setSaved]           = useState(false)
  const [uploadError, setUploadError] = useState(null)
  const [showAI, setShowAI]         = useState(true)
  const [noteId, setNoteId]         = useState(isNew ? null : id)

  const fileRef = useRef()
  const inlineImageRef = useRef()

  const editor = useEditor({
    extensions: [
      StarterKit,
      Image,
      Link.configure({ openOnClick: false }),
      CodeBlock,
      Placeholder.configure({ placeholder: 'Start writing your note…' }),
    ],
    content: '',
    editorProps: { attributes: { class: 'focus:outline-none' } },
  })

  // Load existing note
  useEffect(() => {
    if (!isNew) {
      fetchNote(id).then(() => {})
    }
  }, [id])

  useEffect(() => {
    if (!isNew && currentNote && editor) {
      setTitle(currentNote.title || '')
      setSummary(currentNote.summary || '')
      setTags(currentNote.tags || [])
      setMetaDesc(currentNote.metaDescription || '')
      setStatus(currentNote.status || 'draft')
      setCoverImage(currentNote.coverImage || '')
      editor.commands.setContent(currentNote.content || '')
      setNoteId(currentNote.id)
    }
  }, [currentNote, editor])

  const getContent = () => editor?.getHTML() || ''

  const save = async (publishStatus = status) => {
    setSaving(true)
    try {
      const payload = {
        title,
        content: getContent(),
        summary,
        tags,
        metaDescription: metaDesc,
        status: publishStatus,
        coverImage,
      }
      if (noteId) {
        await updateNote(noteId, payload)
      } else {
        const created = await createNote(payload)
        setNoteId(created.id)
        navigate(`/editor/${created.id}`, { replace: true })
      }
      setSaved(true)
      setTimeout(() => setSaved(false), 2000)
    } finally {
      setSaving(false)
    }
  }

  const handlePublish = () => save('published')

  const addTag = (e) => {
    if ((e.key === 'Enter' || e.key === ',') && tagInput.trim()) {
      e.preventDefault()
      const t = tagInput.trim().replace(/^#/, '')
      if (t && !tags.includes(t)) setTags([...tags, t])
      setTagInput('')
    }
  }
  const removeTag = (t) => setTags(tags.filter((x) => x !== t))

  const handleCoverUpload = async (e) => {
    const file = e.target.files?.[0]
    if (!file) return
    setUploadError(null)
    try {
      const form = new FormData()
      form.append('file', file)
      const { data } = await api.post('/upload', form, { headers: { 'Content-Type': 'multipart/form-data' } })
      setCoverImage(data.url)
    } catch (err) {
      setUploadError(err.response?.data?.message || 'Image upload failed. Please try again.')
    }
  }

  const handleInlineImageUpload = async (e) => {
    const file = e.target.files?.[0]
    if (!file || !editor) return
    setUploadError(null)
    try {
      const form = new FormData()
      form.append('file', file)
      const { data } = await api.post('/upload', form, {
        headers: { 'Content-Type': 'multipart/form-data' },
      })

      editor.chain().focus().setImage({ src: data.url, alt: file.name }).run()
    } catch (err) {
      setUploadError(err.response?.data?.message || 'Image upload failed. Please try again.')
    }
    e.target.value = ''
  }

  const setEditorLink = () => {
    if (!editor) return
    const previous = editor.getAttributes('link').href || 'https://'
    const url = window.prompt('Enter URL', previous)
    if (url === null) return

    const trimmed = url.trim()
    if (!trimmed) {
      editor.chain().focus().extendMarkRange('link').unsetLink().run()
      return
    }

    editor.chain().focus().extendMarkRange('link').setLink({ href: trimmed }).run()
  }

  const handleAIApply = ({ field, value }) => {
    if (field === 'summary') setSummary(value)
    if (field === 'metaDescription') setMetaDesc(value)
    if (field === 'tags' && Array.isArray(value)) setTags([...new Set([...tags, ...value])])
  }

  return (
    <div className="flex h-screen flex-col overflow-hidden">
      {/* Top toolbar */}
      <div className="flex flex-wrap items-center gap-2 border-b border-gray-200 bg-white px-4 py-2 shrink-0">
        <button onClick={() => navigate('/dashboard')} className="btn-ghost text-xs">
          ← Dashboard
        </button>
        <div className="flex-1" />
        <span className={`text-xs ${saved ? 'text-green-600' : 'text-gray-400'}`}>
          {saving ? 'Saving…' : saved ? 'Saved ✓' : 'Unsaved'}
        </span>
        <select
          value={status}
          onChange={(e) => setStatus(e.target.value)}
          className="input w-auto text-xs py-1"
        >
          <option value="draft">Draft</option>
          <option value="published">Published</option>
        </select>
        <button onClick={() => save()} disabled={saving} className="btn-secondary text-xs py-1.5">
          Save
        </button>
        <button onClick={handlePublish} disabled={saving} className="btn-primary text-xs py-1.5">
          Publish
        </button>
        <button
          onClick={() => setShowAI(!showAI)}
          className={`btn-ghost text-xs py-1.5 ${showAI ? 'bg-brand-50 text-brand-600' : ''}`}
        >
          ✨ AI
        </button>
      </div>

      <div className="flex flex-1 min-h-0 flex-col lg:flex-row">
        {/* Main editor area */}
        <div className="flex flex-1 flex-col min-w-0 overflow-y-auto">
          {/* Cover image */}
          <div
            className="relative h-48 bg-gradient-to-r from-brand-100 to-brand-50 flex items-center justify-center cursor-pointer group shrink-0"
            onClick={() => fileRef.current?.click()}
          >
            {coverImage ? (
              <img src={coverImage} alt="Cover" className="absolute inset-0 h-full w-full object-cover" />
            ) : (
              <span className="text-sm text-brand-400 group-hover:text-brand-600 transition">
                + Add cover image
              </span>
            )}
            <input ref={fileRef} type="file" accept="image/*" className="hidden" onChange={handleCoverUpload} />
          </div>

          <div className="mx-auto w-full max-w-3xl px-6 py-8">
            {/* Title */}
            <input
              type="text"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              placeholder="Note title…"
              className="mb-6 w-full text-3xl font-bold text-gray-900 placeholder-gray-300 outline-none bg-transparent"
            />

            {/* Rich text toolbar */}
            {uploadError && (
              <div className="mb-4 rounded-lg border border-red-200 bg-red-50 px-3 py-2 text-xs text-red-700">
                {uploadError}
              </div>
            )}

            {editor && (
              <div className="mb-4 flex flex-wrap gap-1 rounded-lg border border-gray-200 bg-gray-50 p-1.5">
                {TOOLBAR_BUTTONS.map((btn) => (
                  <button
                    key={btn.label}
                    onMouseDown={(e) => { e.preventDefault(); btn.action(editor) }}
                    className={`rounded px-2.5 py-1 text-xs font-mono font-medium transition ${
                      btn.active(editor)
                        ? 'bg-brand-600 text-white'
                        : 'text-gray-600 hover:bg-gray-200'
                    }`}
                  >
                    {btn.label}
                  </button>
                ))}
                <button
                  onMouseDown={(e) => { e.preventDefault(); setEditorLink() }}
                  className={`rounded px-2.5 py-1 text-xs font-mono font-medium transition ${
                    editor.isActive('link') ? 'bg-brand-600 text-white' : 'text-gray-600 hover:bg-gray-200'
                  }`}
                >
                  LINK
                </button>
                <button
                  onMouseDown={(e) => { e.preventDefault(); inlineImageRef.current?.click() }}
                  className="rounded px-2.5 py-1 text-xs font-mono font-medium text-gray-600 transition hover:bg-gray-200"
                >
                  IMG
                </button>
                <input
                  ref={inlineImageRef}
                  type="file"
                  accept="image/*"
                  className="hidden"
                  onChange={handleInlineImageUpload}
                />
              </div>
            )}

            {/* TipTap editor */}
            <EditorContent editor={editor} className="prose max-w-none" />

            {/* Metadata section */}
            <div className="mt-10 space-y-4 border-t border-gray-100 pt-6">
              <h3 className="text-sm font-semibold text-gray-700">Note Metadata</h3>

              {/* Summary */}
              <div>
                <label className="block text-xs font-medium text-gray-500 mb-1">Summary</label>
                <textarea
                  value={summary}
                  onChange={(e) => setSummary(e.target.value)}
                  rows={3}
                  placeholder="Brief summary of this note…"
                  className="input resize-none text-sm"
                />
              </div>

              {/* Tags */}
              <div>
                <label className="block text-xs font-medium text-gray-500 mb-1">Tags</label>
                <div className="flex flex-wrap gap-1.5 mb-2">
                  {tags.map((t) => (
                    <span key={t} className="badge bg-brand-50 text-brand-600 gap-1">
                      #{t}
                      <button onClick={() => removeTag(t)} className="hover:text-brand-900 ml-0.5">×</button>
                    </span>
                  ))}
                </div>
                <input
                  type="text"
                  value={tagInput}
                  onChange={(e) => setTagInput(e.target.value)}
                  onKeyDown={addTag}
                  placeholder="Add tag and press Enter…"
                  className="input text-sm"
                />
              </div>

              {/* Meta description */}
              <div>
                <label className="block text-xs font-medium text-gray-500 mb-1">
                  SEO Meta Description
                </label>
                <textarea
                  value={metaDesc}
                  onChange={(e) => setMetaDesc(e.target.value)}
                  rows={2}
                  placeholder="Description for search engines…"
                  className="input resize-none text-sm"
                />
                <p className={`mt-1 text-xs ${metaDesc.length > 160 ? 'text-red-500' : 'text-gray-400'}`}>
                  {metaDesc.length}/160 characters
                </p>
              </div>
            </div>
          </div>
        </div>

        {/* AI panel */}
        {showAI && (
          <AIPanel
            noteId={noteId}
            content={getContent()}
            onApply={handleAIApply}
            className="max-h-80 lg:max-h-none"
          />
        )}
      </div>
    </div>
  )
}
