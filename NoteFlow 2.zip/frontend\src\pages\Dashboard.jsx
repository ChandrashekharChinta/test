import { useEffect, useState } from 'react'
import { Link, useSearchParams } from 'react-router-dom'
import Sidebar from '../components/Sidebar'
import NoteCard from '../components/NoteCard'
import SearchBar from '../components/SearchBar'
import { useNoteStore } from '../store/noteStore'

const STATUS_FILTERS = ['all', 'draft', 'published']
const TAG_SORT = ['Newest', 'Oldest', 'A–Z']

export default function Dashboard() {
  const [searchParams] = useSearchParams()
  const statusParam = searchParams.get('status') || 'all'

  const { notes, loading, error, fetchNotes } = useNoteStore()

  const [search, setSearch]     = useState('')
  const [status, setStatus]     = useState(statusParam)
  const [sortBy, setSortBy]     = useState('Newest')
  const [tagFilter, setTagFilter] = useState('')
  const [authorFilter, setAuthorFilter] = useState('')
  const [dateFilter, setDateFilter] = useState('')
  const [debouncedFilters, setDebouncedFilters] = useState({
    search: '',
    status: statusParam,
    tagFilter: '',
    authorFilter: '',
    dateFilter: '',
  })

  useEffect(() => {
    const timer = setTimeout(() => {
      setDebouncedFilters({ search, status, tagFilter, authorFilter, dateFilter })
    }, 300)

    return () => clearTimeout(timer)
  }, [search, status, tagFilter, authorFilter, dateFilter])

  useEffect(() => {
    const controller = new AbortController()
    fetchNotes({
      search: debouncedFilters.search,
      status: debouncedFilters.status === 'all' ? undefined : debouncedFilters.status,
      tag: debouncedFilters.tagFilter || undefined,
      author: debouncedFilters.authorFilter || undefined,
      date: debouncedFilters.dateFilter || undefined,
    }, controller.signal)

    return () => controller.abort()
  }, [debouncedFilters, fetchNotes])

  const allTags = [...new Set(notes.flatMap((n) => n.tags || []))]

  const sorted = [...notes].sort((a, b) => {
    if (sortBy === 'Newest') return new Date(b.updatedAt) - new Date(a.updatedAt)
    if (sortBy === 'Oldest') return new Date(a.updatedAt) - new Date(b.updatedAt)
    return (a.title || '').localeCompare(b.title || '')
  })

  return (
    <div className="flex min-h-screen">
      <Sidebar />

      <main className="flex-1 min-w-0 p-6">
        {/* Header */}
        <div className="mb-6 flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
          <div>
            <h1 className="text-xl font-bold text-gray-900">My Notes</h1>
            <p className="text-sm text-gray-500">{notes.length} note{notes.length !== 1 ? 's' : ''}</p>
          </div>
          <Link to="/editor/new" className="btn-primary self-start sm:self-auto">
            + New Note
          </Link>
        </div>

        {/* Filters row */}
        <div className="mb-5 flex flex-wrap gap-3 items-center">
          <div className="flex-1 min-w-48">
            <SearchBar value={search} onChange={setSearch} />
          </div>

          {/* Status tabs */}
          <div className="flex gap-1 bg-gray-100 p-1 rounded-lg">
            {STATUS_FILTERS.map((s) => (
              <button
                key={s}
                onClick={() => setStatus(s)}
                className={`px-3 py-1 rounded-md text-xs font-medium capitalize transition ${
                  status === s ? 'bg-white shadow text-gray-900' : 'text-gray-500 hover:text-gray-700'
                }`}
              >
                {s}
              </button>
            ))}
          </div>

          {/* Sort */}
          <select
            value={sortBy}
            onChange={(e) => setSortBy(e.target.value)}
            className="input w-auto text-sm py-1.5"
          >
            {TAG_SORT.map((s) => <option key={s}>{s}</option>)}
          </select>

          <input
            type="text"
            value={authorFilter}
            onChange={(e) => setAuthorFilter(e.target.value)}
            placeholder="Author ID"
            className="input w-auto text-sm py-1.5"
            aria-label="Filter by author"
          />

          <input
            type="date"
            value={dateFilter}
            onChange={(e) => setDateFilter(e.target.value)}
            className="input w-auto text-sm py-1.5"
            aria-label="Filter by date"
          />
        </div>

        {/* Tag filter chips */}
        {allTags.length > 0 && (
          <div className="mb-5 flex flex-wrap gap-2">
            <button
              onClick={() => setTagFilter('')}
              className={`badge px-3 py-1 text-xs font-medium transition ${
                !tagFilter ? 'bg-brand-600 text-white' : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
              }`}
            >
              All
            </button>
            {allTags.slice(0, 15).map((tag, index) => (
              <button
                key={`${tag}-${index}`}
                onClick={() => setTagFilter(tag === tagFilter ? '' : tag)}
                className={`badge px-3 py-1 text-xs font-medium transition ${
                  tagFilter === tag
                    ? 'bg-brand-600 text-white'
                    : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
                }`}
              >
                #{tag}
              </button>
            ))}
          </div>
        )}

        {/* Error */}
        {error && (
          <div className="mb-4 rounded-lg bg-red-50 border border-red-200 p-4 text-sm text-red-700">
            {error}
          </div>
        )}

        {/* Notes grid */}
        {loading ? (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {Array.from({ length: 6 }).map((_, i) => (
              <div key={i} className="card h-52 animate-pulse bg-gray-100" />
            ))}
          </div>
        ) : sorted.length === 0 ? (
          <div className="flex flex-col items-center justify-center py-24 text-center">
            <span className="text-5xl mb-4">📝</span>
            <h2 className="text-lg font-semibold text-gray-700 mb-1">No notes yet</h2>
            <p className="text-sm text-gray-400 mb-6">Create your first note to get started</p>
            <Link to="/editor/new" className="btn-primary">+ New Note</Link>
          </div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {sorted.map((note) => (
              <NoteCard key={note.id} note={note} onDelete={() => fetchNotes()} />
            ))}
          </div>
        )}
      </main>
    </div>
  )
}
