import { create } from 'zustand'
import api from '../api/axios'

export const useNoteStore = create((set, get) => ({
  notes: [],
  currentNote: null,
  loading: false,
  error: null,

  fetchNotes: async (params = {}, signal) => {
    set({ loading: true, error: null })
    try {
      const { data } = await api.get('/notes', { params, signal })
      set({ notes: data, loading: false })
    } catch (err) {
      if (err.code === 'ERR_CANCELED') {
        set({ loading: false })
        return
      }
      set({ error: err.response?.data?.message || 'Failed to load notes', loading: false })
    }
  },

  fetchNote: async (id) => {
    set({ loading: true, error: null })
    try {
      const { data } = await api.get(`/notes/${id}`)
      set({ currentNote: data, loading: false })
    } catch (err) {
      set({ error: err.response?.data?.message || 'Failed to load note', loading: false })
    }
  },

  createNote: async (payload) => {
    set({ loading: true, error: null })
    try {
      const { data } = await api.post('/notes', payload)
      set((s) => ({ notes: [data, ...s.notes], loading: false }))
      return data
    } catch (err) {
      set({ error: err.response?.data?.message || 'Failed to create note', loading: false })
      throw err
    }
  },

  updateNote: async (id, payload) => {
    set({ loading: true, error: null })
    try {
      const { data } = await api.put(`/notes/${id}`, payload)
      set((s) => ({
        notes: s.notes.map((n) => (n.id === id ? data : n)),
        currentNote: data,
        loading: false,
      }))
      return data
    } catch (err) {
      set({ error: err.response?.data?.message || 'Failed to update note', loading: false })
      throw err
    }
  },

  deleteNote: async (id) => {
    set({ loading: true, error: null })
    try {
      await api.delete(`/notes/${id}`)
      set((s) => ({ notes: s.notes.filter((n) => n.id !== id), loading: false }))
    } catch (err) {
      set({ error: err.response?.data?.message || 'Failed to delete note', loading: false })
      throw err
    }
  },

  // AI actions
  aiLoading: {},
  generateSummary: async (id, content) => {
    set((s) => ({ aiLoading: { ...s.aiLoading, summary: true } }))
    try {
      const { data } = await api.post(`/notes/${id}/ai/summary`, { content })
      return data.summary
    } finally {
      set((s) => ({ aiLoading: { ...s.aiLoading, summary: false } }))
    }
  },

  generateTags: async (id, content) => {
    set((s) => ({ aiLoading: { ...s.aiLoading, tags: true } }))
    try {
      const { data } = await api.post(`/notes/${id}/ai/tags`, { content })
      return data.tags
    } finally {
      set((s) => ({ aiLoading: { ...s.aiLoading, tags: false } }))
    }
  },

  generateMetaDescription: async (id, content) => {
    set((s) => ({ aiLoading: { ...s.aiLoading, meta: true } }))
    try {
      const { data } = await api.post(`/notes/${id}/ai/meta`, { content })
      return data.metaDescription
    } finally {
      set((s) => ({ aiLoading: { ...s.aiLoading, meta: false } }))
    }
  },

  suggestIdeas: async (id, content) => {
    set((s) => ({ aiLoading: { ...s.aiLoading, ideas: true } }))
    try {
      const { data } = await api.post(`/notes/${id}/ai/ideas`, { content })
      return data.ideas
    } finally {
      set((s) => ({ aiLoading: { ...s.aiLoading, ideas: false } }))
    }
  },
}))
