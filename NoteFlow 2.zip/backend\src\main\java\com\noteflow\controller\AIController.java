package com.noteflow.controller;

import java.util.List;
import java.util.Map;

import jakarta.validation.Valid;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.noteflow.dto.ai.AiContentRequest;
import com.noteflow.service.AIService;
import com.noteflow.util.AuthUtil;

import lombok.RequiredArgsConstructor;

@RestController
@RequestMapping("/api/notes/{id}/ai")
@RequiredArgsConstructor
public class AIController {

    private final AIService aiService;

    @PostMapping("/summary")
    public ResponseEntity<Map<String, String>> summary(@PathVariable("id") String noteId, @Valid @RequestBody AiContentRequest request) {
        String summary = aiService.generateSummary(AuthUtil.currentUserId(), noteId, request.getContent());
        return ResponseEntity.ok(Map.of("summary", summary));
    }

    @PostMapping("/tags")
    public ResponseEntity<Map<String, List<String>>> tags(@PathVariable("id") String noteId, @Valid @RequestBody AiContentRequest request) {
        List<String> tags = aiService.generateTags(AuthUtil.currentUserId(), noteId, request.getContent());
        return ResponseEntity.ok(Map.of("tags", tags));
    }

    @PostMapping("/meta")
    public ResponseEntity<Map<String, String>> meta(@PathVariable("id") String noteId, @Valid @RequestBody AiContentRequest request) {
        String meta = aiService.generateMetaDescription(AuthUtil.currentUserId(), noteId, request.getContent());
        return ResponseEntity.ok(Map.of("metaDescription", meta));
    }

    @PostMapping("/ideas")
    public ResponseEntity<Map<String, List<String>>> ideas(@PathVariable("id") String noteId, @Valid @RequestBody AiContentRequest request) {
        List<String> ideas = aiService.suggestIdeas(AuthUtil.currentUserId(), noteId, request.getContent());
        return ResponseEntity.ok(Map.of("ideas", ideas));
    }
}
