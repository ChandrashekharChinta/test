package com.noteflow.controller;

import java.util.List;

import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.noteflow.dto.note.NoteRequest;
import com.noteflow.dto.note.NoteResponse;
import com.noteflow.service.NoteService;
import com.noteflow.util.AuthUtil;

import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;

@RestController
@RequestMapping("/api/notes")
@Validated
@RequiredArgsConstructor
public class NoteController {

    private final NoteService noteService;

    @GetMapping
    public ResponseEntity<List<NoteResponse>> getMyNotes(
            @RequestParam(required = false) String search,
            @RequestParam(required = false) String status,
            @RequestParam(required = false) String tag,
            @RequestParam(required = false) String author,
            @RequestParam(required = false) String date) {
        return ResponseEntity.ok(noteService.listMyNotes(AuthUtil.currentUserId(), search, status, tag, author, date));
    }

    @GetMapping("/{id}")
    public ResponseEntity<NoteResponse> getById(@PathVariable String id) {
        return ResponseEntity.ok(noteService.getMyNote(AuthUtil.currentUserId(), id));
    }

    @PostMapping
    public ResponseEntity<NoteResponse> create(@Valid @RequestBody NoteRequest request) {
        return ResponseEntity.ok(noteService.create(AuthUtil.currentUserId(), request));
    }

    @PutMapping("/{id}")
    public ResponseEntity<NoteResponse> update(@PathVariable String id, @Valid @RequestBody NoteRequest request) {
        return ResponseEntity.ok(noteService.update(AuthUtil.currentUserId(), id, request));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> delete(@PathVariable String id) {
        noteService.delete(AuthUtil.currentUserId(), id);
        return ResponseEntity.noContent().build();
    }
}
