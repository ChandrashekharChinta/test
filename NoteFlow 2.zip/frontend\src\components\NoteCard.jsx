import { Link } from 'react-router-dom'
import { useNoteStore } from '../store/noteStore'

const STATUS_BADGE = {
  draft:     'badge bg-yellow-100 text-yellow-700',
  published: 'badge bg-green-100 text-green-700',
}

export default function NoteCard({ note, onDelete }) {
  const deleteNote = useNoteStore((s) => s.deleteNote)

  const handleDelete = async (e) => {
    e.preventDefault()
    if (!window.confirm('Delete this note?')) return
    await deleteNote(note.id)
    onDelete?.()
  }

  return (
    <article className="card group flex flex-col hover:shadow-md transition-shadow">
      {/* Cover image */}
      {note.coverImage && (
        <img
          src={note.coverImage}
          alt={note.title}
          className="h-40 w-full rounded-t-xl object-cover"
        />
      )}

      <div className="flex flex-col flex-1 p-5">
        {/* Status + date */}
        <div className="mb-2 flex items-center gap-2">
          <span className={STATUS_BADGE[note.status] || STATUS_BADGE.draft}>
            {note.status}
          </span>
          <span className="text-xs text-gray-400">
            {new Date(note.updatedAt).toLocaleDateString()}
          </span>
        </div>

        {/* Title */}
        <h2 className="mb-1 text-base font-semibold text-gray-900 line-clamp-2 group-hover:text-brand-600 transition-colors">
          {note.title || 'Untitled'}
        </h2>

        {/* Summary */}
        {note.summary && (
          <p className="mb-3 text-sm text-gray-500 line-clamp-2">{note.summary}</p>
        )}

        {/* Tags */}
        {note.tags?.length > 0 && (
          <div className="mb-4 flex flex-wrap gap-1">
            {note.tags.slice(0, 4).map((tag, index) => (
              <span key={`${tag}-${index}`} className="badge bg-brand-50 text-brand-600">
                #{tag}
              </span>
            ))}
          </div>
        )}

        {/* Actions */}
        <div className="mt-auto flex items-center gap-2 pt-3 border-t border-gray-100">
          <Link to={`/editor/${note.id}`} className="btn-secondary flex-1 justify-center text-xs py-1.5">
            Edit
          </Link>
          {note.status === 'published' && (
            <Link to={`/articles/${note.id}`} className="btn-ghost text-xs py-1.5">
              View ↗
            </Link>
          )}
          <button
            onClick={handleDelete}
            className="btn-ghost text-xs py-1.5 text-red-500 hover:text-red-700 hover:bg-red-50"
          >
            Delete
          </button>
        </div>
      </div>
    </article>
  )
}
