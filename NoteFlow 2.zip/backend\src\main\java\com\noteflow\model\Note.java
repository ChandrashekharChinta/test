package com.noteflow.model;

import java.time.Instant;
import java.util.ArrayList;
import java.util.List;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.index.Indexed;
import org.springframework.data.mongodb.core.mapping.Document;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Document(collection = "notes")
public class Note {

    @Id
    private String id;

    @Indexed
    private String authorId;

    private String title;

    private String content;

    private String summary;

    @Builder.Default
    private List<String> tags = new ArrayList<>();

    private String metaDescription;

    private String coverImage;

    @Builder.Default
    private String status = "draft";

    private Instant createdAt;

    private Instant updatedAt;

    private Instant publishedAt;
}
