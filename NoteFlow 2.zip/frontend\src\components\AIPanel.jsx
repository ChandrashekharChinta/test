import { useState } from 'react'
import { useNoteStore } from '../store/noteStore'

const ACTIONS = [
  { key: 'summary',  label: 'Summarize',        icon: '✨', field: 'summary' },
  { key: 'tags',     label: 'Generate Tags',     icon: '🏷️', field: 'tags' },
  { key: 'meta',     label: 'Meta Description',  icon: '🔍', field: 'metaDescription' },
  { key: 'ideas',    label: 'Suggest Ideas',     icon: '💡', field: null },
]

export default function AIPanel({ noteId, content, onApply, className = '' }) {
  const { aiLoading, generateSummary, generateTags, generateMetaDescription, suggestIdeas } =
    useNoteStore()
  const [results, setResults] = useState({})
  const [error, setError]   = useState(null)

  const handlers = {
    summary: () => generateSummary(noteId, content),
    tags:    () => generateTags(noteId, content),
    meta:    () => generateMetaDescription(noteId, content),
    ideas:   () => suggestIdeas(noteId, content),
  }

  const run = async (key) => {
    setError(null)
    try {
      const result = await handlers[key]()
      setResults((r) => ({ ...r, [key]: result }))
    } catch {
      setError('AI request failed. Please try again.')
    }
  }

  const apply = (action) => {
    if (!results[action.key]) return
    onApply?.({ field: action.field, value: results[action.key] })
  }

  return (
    <aside className={`w-full shrink-0 border-t border-gray-200 bg-white flex flex-col lg:w-72 lg:border-t-0 lg:border-l ${className}`}>
      <div className="border-b border-gray-200 px-4 py-3">
        <h3 className="text-sm font-semibold text-gray-900 flex items-center gap-2">
          <span>✨</span> AI Assistant
        </h3>
        <p className="mt-0.5 text-xs text-gray-400">Claude-powered content tools</p>
      </div>

      <div className="flex-1 overflow-y-auto p-4 space-y-4">
        {error && (
          <div className="rounded-lg bg-red-50 border border-red-200 p-3 text-xs text-red-700">
            {error}
          </div>
        )}

        {ACTIONS.map((action) => {
          const loading = aiLoading[action.key]
          const result  = results[action.key]

          return (
            <div key={action.key} className="space-y-2">
              <button
                onClick={() => run(action.key)}
                disabled={loading || !content}
                className="btn-secondary w-full justify-start text-xs"
              >
                <span>{action.icon}</span>
                {loading ? 'Generating…' : action.label}
                {loading && (
                  <svg className="ml-auto h-3 w-3 animate-spin text-brand-500" viewBox="0 0 24 24" fill="none">
                    <circle cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" className="opacity-25" />
                    <path fill="currentColor" d="M4 12a8 8 0 018-8v8H4z" className="opacity-75" />
                  </svg>
                )}
              </button>

              {result && (
                <div className="rounded-lg border border-gray-100 bg-gray-50 p-3">
                  {Array.isArray(result) ? (
                    <>
                      <div className="flex flex-wrap gap-1 mb-2">
                        {result.map((item, i) => (
                          <span key={`${String(typeof item === 'string' ? item : item.title || item)}-${i}`} className="badge bg-brand-50 text-brand-600 text-xs">
                            {typeof item === 'string' ? item : item.title || item}
                          </span>
                        ))}
                      </div>
                    </>
                  ) : (
                    <p className="text-xs text-gray-700 leading-relaxed">{result}</p>
                  )}
                  {action.field && (
                    <button
                      onClick={() => apply(action)}
                      className="mt-2 text-xs font-medium text-brand-600 hover:text-brand-800 transition"
                    >
                      ← Apply to note
                    </button>
                  )}
                </div>
              )}
            </div>
          )
        })}
      </div>

      <div className="border-t border-gray-100 px-4 py-3">
        <p className="text-[10px] text-gray-400 text-center">Powered by Claude API</p>
      </div>
    </aside>
  )
}
