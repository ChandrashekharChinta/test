package com.noteflow.dto.note;

import java.time.Instant;
import java.util.List;

import com.noteflow.model.Note;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class PublicNoteResponse {

    private String id;
    private String title;
    private String content;
    private String summary;
    private List<String> tags;
    private String metaDescription;
    private String coverImage;
    private Instant publishedAt;
    private Author author;

    @Data
    @Builder
    public static class Author {
        private String id;
        private String name;
    }

    public static PublicNoteResponse from(Note note, String authorName) {
        return PublicNoteResponse.builder()
                .id(note.getId())
                .title(note.getTitle())
                .content(note.getContent())
                .summary(note.getSummary())
                .tags(note.getTags())
                .metaDescription(note.getMetaDescription())
                .coverImage(note.getCoverImage())
                .publishedAt(note.getPublishedAt())
                .author(Author.builder().id(note.getAuthorId()).name(authorName).build())
                .build();
    }
}
