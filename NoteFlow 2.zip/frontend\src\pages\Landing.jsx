import { Link } from 'react-router-dom'

export default function Landing() {
  return (
    <div className="min-h-screen">
      {/* Hero */}
      <section className="relative overflow-hidden bg-gradient-to-br from-brand-600 to-brand-800 py-24 text-white">
        <div className="mx-auto max-w-4xl px-4 text-center">
          <span className="mb-4 inline-block rounded-full bg-white/20 px-4 py-1 text-xs font-semibold uppercase tracking-wider">
            AI-Powered Note Taking
          </span>
          <h1 className="mt-4 text-5xl font-extrabold leading-tight mb-6">
            Write, Publish &amp; Let<br />AI Handle the Rest
          </h1>
          <p className="mx-auto max-w-xl text-brand-100 text-lg mb-10">
            NoteFlow is a rich-text note editor with built-in AI tools — auto-summarize, generate tags,
            create SEO descriptions, and get content ideas with one click.
          </p>
          <div className="flex flex-col sm:flex-row gap-3 justify-center">
            <Link to="/register" className="btn-primary bg-white text-brand-700 hover:bg-brand-50 text-base px-6 py-3">
              Get Started Free
            </Link>
            <Link to="/articles" className="btn-ghost text-white hover:bg-white/10 text-base px-6 py-3">
              Browse Articles →
            </Link>
          </div>
        </div>
      </section>

      {/* Features */}
      <section className="mx-auto max-w-5xl px-4 py-20">
        <h2 className="mb-12 text-center text-3xl font-bold text-gray-900">Everything you need</h2>
        <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
          {FEATURES.map((f) => (
            <div key={f.title} className="card p-6">
              <span className="text-3xl mb-4 block">{f.icon}</span>
              <h3 className="mb-2 text-base font-semibold text-gray-900">{f.title}</h3>
              <p className="text-sm text-gray-500">{f.desc}</p>
            </div>
          ))}
        </div>
      </section>

      {/* CTA */}
      <section className="bg-brand-50 py-16 text-center">
        <h2 className="text-3xl font-bold text-gray-900 mb-4">Ready to write smarter?</h2>
        <p className="text-gray-500 mb-8">Join NoteFlow and publish your first AI-enhanced article today.</p>
        <Link to="/register" className="btn-primary text-base px-8 py-3">
          Create Free Account
        </Link>
      </section>
    </div>
  )
}

const FEATURES = [
  { icon: '✍️', title: 'Rich Text Editor',        desc: 'Full TipTap editor with headings, lists, links, code blocks, and inline images.' },
  { icon: '✨', title: 'AI Summarization',         desc: 'Claude generates a concise summary of your content with a single click.' },
  { icon: '🏷️', title: 'Smart Tag Generation',    desc: 'Automatically extract relevant tags from your article topic.' },
  { icon: '🔍', title: 'SEO Meta Descriptions',   desc: 'Generate search-engine-friendly meta descriptions for published notes.' },
  { icon: '💡', title: 'Content Idea Suggestions', desc: 'Get related article ideas to keep your writing momentum going.' },
  { icon: '🌐', title: 'Public Publishing',        desc: 'Publish notes as public articles with their own shareable URL.' },
]
