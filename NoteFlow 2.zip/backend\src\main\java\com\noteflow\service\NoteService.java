package com.noteflow.service;

import java.time.Instant;
import java.time.LocalDate;
import java.time.ZoneOffset;
import java.time.format.DateTimeParseException;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.stream.Collectors;

import org.springframework.stereotype.Service;

import com.noteflow.dto.note.NoteRequest;
import com.noteflow.dto.note.NoteResponse;
import com.noteflow.dto.note.PublicNoteResponse;
import com.noteflow.model.Note;
import com.noteflow.model.User;
import com.noteflow.repository.NoteRepository;
import com.noteflow.repository.UserRepository;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class NoteService {

    private final NoteRepository noteRepository;
    private final UserRepository userRepository;

    public List<NoteResponse> listMyNotes(String userId, String search, String status, String tag, String author, String date) {
        LocalDate parsedDate = parseDate(date);
        List<Note> notes;
        if (status != null && !status.isBlank()) {
            notes = noteRepository.findByAuthorIdAndStatusOrderByUpdatedAtDesc(userId, status.toLowerCase(Locale.ROOT));
        } else {
            notes = noteRepository.findByAuthorIdOrderByUpdatedAtDesc(userId);
        }

        return notes.stream()
                .filter(note -> matchesSearch(note, search))
                .filter(note -> matchesTag(note, tag))
            .filter(note -> matchesAuthorId(note, author))
            .filter(note -> matchesDate(note.getUpdatedAt(), parsedDate))
                .map(NoteResponse::from)
                .collect(Collectors.toList());
    }

    public NoteResponse getMyNote(String userId, String noteId) {
        Note note = noteRepository.findByIdAndAuthorId(noteId, userId)
                .orElseThrow(() -> new IllegalArgumentException("Note not found."));
        return NoteResponse.from(note);
    }

    public NoteResponse create(String userId, NoteRequest request) {
        Instant now = Instant.now();
        String status = normalizeStatus(request.getStatus());

        Note note = Note.builder()
                .authorId(userId)
                .title(request.getTitle().trim())
                .content(safe(request.getContent()))
                .summary(safe(request.getSummary()))
                .tags(request.getTags() == null ? List.of() : request.getTags())
                .metaDescription(safe(request.getMetaDescription()))
                .coverImage(safe(request.getCoverImage()))
                .status(status)
                .createdAt(now)
                .updatedAt(now)
                .publishedAt("published".equals(status) ? now : null)
                .build();

        return NoteResponse.from(noteRepository.save(note));
    }

    public NoteResponse update(String userId, String noteId, NoteRequest request) {
        Note note = noteRepository.findByIdAndAuthorId(noteId, userId)
                .orElseThrow(() -> new IllegalArgumentException("Note not found."));

        note.setTitle(request.getTitle().trim());
        note.setContent(safe(request.getContent()));
        note.setSummary(safe(request.getSummary()));
        note.setTags(request.getTags() == null ? List.of() : request.getTags());
        note.setMetaDescription(safe(request.getMetaDescription()));
        note.setCoverImage(safe(request.getCoverImage()));

        String status = normalizeStatus(request.getStatus());
        note.setStatus(status);
        if ("published".equals(status) && note.getPublishedAt() == null) {
            note.setPublishedAt(Instant.now());
        }
        note.setUpdatedAt(Instant.now());

        return NoteResponse.from(noteRepository.save(note));
    }

    public void delete(String userId, String noteId) {
        Note note = noteRepository.findByIdAndAuthorId(noteId, userId)
                .orElseThrow(() -> new IllegalArgumentException("Note not found."));
        noteRepository.delete(note);
    }

    public List<PublicNoteResponse> listPublic(String search, String tag, String author, String date) {
        LocalDate parsedDate = parseDate(date);
        Map<String, String> authorNames = new HashMap<>();

        return noteRepository.findByStatusOrderByPublishedAtDesc("published")
                .stream()
                .map(note -> Map.entry(note, resolveAuthorName(note.getAuthorId(), authorNames)))
                .filter(entry -> matchesAuthorName(entry.getValue(), author))
            .filter(entry -> matchesSearch(entry.getKey(), search))
            .filter(entry -> matchesTag(entry.getKey(), tag))
                .filter(entry -> matchesDate(entry.getKey().getPublishedAt(), parsedDate))
                .map(entry -> PublicNoteResponse.from(entry.getKey(), entry.getValue()))
                .collect(Collectors.toList());
    }

    public PublicNoteResponse getPublicById(String noteId) {
        Note note = noteRepository.findByIdAndStatus(noteId, "published")
                .orElseThrow(() -> new IllegalArgumentException("Article not found."));
        return toPublicResponse(note);
    }

    private PublicNoteResponse toPublicResponse(Note note) {
        String authorName = resolveAuthorName(note.getAuthorId(), new HashMap<>());
        return PublicNoteResponse.from(note, authorName);
    }

    private String resolveAuthorName(String authorId, Map<String, String> cache) {
        return cache.computeIfAbsent(authorId,
                id -> userRepository.findById(id).map(User::getName).orElse("Unknown"));
    }

    private boolean matchesSearch(Note note, String search) {
        if (search == null || search.isBlank()) {
            return true;
        }

        String needle = search.toLowerCase(Locale.ROOT);
        return safe(note.getTitle()).toLowerCase(Locale.ROOT).contains(needle)
                || safe(note.getContent()).toLowerCase(Locale.ROOT).contains(needle)
                || note.getTags().stream().anyMatch(tag -> tag != null && tag.toLowerCase(Locale.ROOT).contains(needle));
    }

    private boolean matchesTag(Note note, String tag) {
        if (tag == null || tag.isBlank()) {
            return true;
        }
        String normalized = tag.toLowerCase(Locale.ROOT);
        return note.getTags().stream().anyMatch(t -> t != null && t.toLowerCase(Locale.ROOT).equals(normalized));
    }

    private boolean matchesAuthorId(Note note, String author) {
        if (author == null || author.isBlank()) {
            return true;
        }
        return safe(note.getAuthorId()).equalsIgnoreCase(author.trim());
    }

    private boolean matchesAuthorName(String authorName, String authorFilter) {
        if (authorFilter == null || authorFilter.isBlank()) {
            return true;
        }
        return safe(authorName).toLowerCase(Locale.ROOT).contains(authorFilter.toLowerCase(Locale.ROOT).trim());
    }

    private LocalDate parseDate(String date) {
        if (date == null || date.isBlank()) {
            return null;
        }
        try {
            return LocalDate.parse(date.trim());
        } catch (DateTimeParseException ex) {
            throw new IllegalArgumentException("Invalid date format. Use YYYY-MM-DD.");
        }
    }

    private boolean matchesDate(Instant instant, LocalDate date) {
        if (date == null) {
            return true;
        }
        if (instant == null) {
            return false;
        }
        return instant.atZone(ZoneOffset.UTC).toLocalDate().equals(date);
    }

    private String normalizeStatus(String status) {
        if (status == null || status.isBlank()) {
            return "draft";
        }
        return "published".equalsIgnoreCase(status) ? "published" : "draft";
    }

    private String safe(String value) {
        return value == null ? "" : value;
    }
}
