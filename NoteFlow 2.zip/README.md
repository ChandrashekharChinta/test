# NoteFlow

## Prerequisites
- Java 17+
- Node.js 18+
- Maven 3.9+ (or use the wrapper)
- PostgreSQL (configure in backend/src/main/resources/application.properties)

## Build & Run

### Backend
`
cd backend
mvn clean package -DskipTests
java -jar target/backend-0.0.1-SNAPSHOT.jar
`
Backend runs on http://localhost:8080

### Frontend
`
cd frontend
npm install
npm run dev
`
Frontend runs on http://localhost:5173

## Configuration
Edit ackend/src/main/resources/application.properties to set your database credentials, JWT secret, and any other settings before running.
