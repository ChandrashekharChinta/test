import { useEffect, useState } from 'react'
import { useParams, Link } from 'react-router-dom'
import DOMPurify from 'dompurify'
import api from '../api/axios'

export default function PublicArticle() {
  const { id }  = useParams()
  const [article, setArticle] = useState(null)
  const [loading, setLoading] = useState(true)
  const [error, setError]     = useState(null)

  const sanitizedHtml = DOMPurify.sanitize(article?.content || '')

  useEffect(() => {
    const load = async () => {
      try {
        const { data } = await api.get(`/public/articles/${id}`)
        setArticle(data)
        document.title = `${data.title} — NoteFlow`
      } catch {
        setError('Article not found.')
      } finally {
        setLoading(false)
      }
    }
    load()
    return () => { document.title = 'NoteFlow' }
  }, [id])

  useEffect(() => {
    if (!article?.metaDescription) return undefined

    const existing = document.querySelector('meta[name="description"]')
    const previous = existing?.getAttribute('content') ?? null
    const meta = existing || document.createElement('meta')

    if (!existing) {
      meta.setAttribute('name', 'description')
      document.head.appendChild(meta)
    }

    meta.setAttribute('content', article.metaDescription)

    return () => {
      if (!existing) {
        meta.remove()
        return
      }
      if (previous === null) {
        existing.removeAttribute('content')
      } else {
        existing.setAttribute('content', previous)
      }
    }
  }, [article?.metaDescription])

  if (loading) return (
    <div className="mx-auto max-w-2xl px-4 py-16 space-y-4">
      <div className="h-10 bg-gray-200 rounded animate-pulse w-3/4" />
      <div className="h-4  bg-gray-100 rounded animate-pulse" />
      <div className="h-4  bg-gray-100 rounded animate-pulse w-5/6" />
    </div>
  )

  if (error) return (
    <div className="flex flex-col items-center justify-center py-32 text-center">
      <span className="text-5xl mb-4">😕</span>
      <p className="text-gray-500 mb-4">{error}</p>
      <Link to="/articles" className="btn-primary">Back to Articles</Link>
    </div>
  )

  return (
    <div className="mx-auto max-w-2xl px-4 py-12">
      {/* Cover */}
      {article.coverImage && (
        <img
          src={article.coverImage}
          alt={article.title}
          className="mb-8 h-72 w-full rounded-2xl object-cover shadow"
        />
      )}

      {/* Header */}
      <div className="mb-8">
        <div className="mb-3 flex flex-wrap gap-1">
          {article.tags?.map((t) => (
            <span key={t} className="badge bg-brand-50 text-brand-600">#{t}</span>
          ))}
        </div>
        <h1 className="text-4xl font-bold text-gray-900 mb-4">{article.title}</h1>
        {article.summary && (
          <p className="text-lg text-gray-500 leading-relaxed">{article.summary}</p>
        )}
        <div className="mt-4 flex items-center gap-3 border-t border-gray-100 pt-4">
          <div className="flex h-9 w-9 items-center justify-center rounded-full bg-brand-100 text-brand-700 text-sm font-semibold uppercase">
            {article.author?.name?.charAt(0)}
          </div>
          <div>
            <p className="text-sm font-medium text-gray-900">{article.author?.name}</p>
            <p className="text-xs text-gray-400">
              {new Date(article.publishedAt).toLocaleDateString('en-US', {
                year: 'numeric', month: 'long', day: 'numeric',
              })}
            </p>
          </div>
        </div>
      </div>

      {/* Content */}
      <div
        className="prose prose-gray max-w-none"
        dangerouslySetInnerHTML={{ __html: sanitizedHtml }}
      />

      {/* Back */}
      <div className="mt-12 border-t border-gray-100 pt-6">
        <Link to="/articles" className="btn-secondary">← Back to Articles</Link>
      </div>
    </div>
  )
}
