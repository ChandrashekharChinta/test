import { create } from 'zustand'
import { persist } from 'zustand/middleware'
import api from '../api/axios'

export const useAuthStore = create(
  persist(
    (set) => ({
      user: null,
      token: null,

      login: async (email, password) => {
        const { data } = await api.post('/auth/login', { email, password })
        set({ user: data.user, token: data.token })
      },

      register: async (name, email, password) => {
        const { data } = await api.post('/auth/register', { name, email, password })
        set({ user: data.user, token: data.token })
      },

      updateProfile: async (payload) => {
        const { data } = await api.put('/users/me', payload)
        set({ user: data })
      },

      logout: () => set({ user: null, token: null }),
    }),
    { name: 'noteflow-auth' }
  )
)
