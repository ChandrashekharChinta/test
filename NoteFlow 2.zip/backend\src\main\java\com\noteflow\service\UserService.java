package com.noteflow.service;

import java.time.Instant;
import java.util.Locale;

import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import com.noteflow.dto.user.UpdateProfileRequest;
import com.noteflow.dto.user.UserResponse;
import com.noteflow.model.User;
import com.noteflow.repository.UserRepository;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class UserService {

    private final UserRepository userRepository;
    private final PasswordEncoder passwordEncoder;

    public UserResponse getById(String userId) {
        User user = userRepository.findById(userId)
                .orElseThrow(() -> new IllegalArgumentException("User not found."));
        return UserResponse.from(user);
    }

    public UserResponse updateProfile(String userId, UpdateProfileRequest request) {
        User user = userRepository.findById(userId)
                .orElseThrow(() -> new IllegalArgumentException("User not found."));

        String normalizedEmail = request.getEmail().trim().toLowerCase(Locale.ROOT);

        if (!user.getEmail().equalsIgnoreCase(request.getEmail())
            && userRepository.existsByEmail(normalizedEmail)) {
            throw new IllegalArgumentException("Email already in use.");
        }

        user.setName(request.getName().trim());
        user.setEmail(normalizedEmail);

        if (request.getPassword() != null && !request.getPassword().isBlank()) {
            user.setPassword(passwordEncoder.encode(request.getPassword()));
        }

        user.setUpdatedAt(Instant.now());

        return UserResponse.from(userRepository.save(user));
    }
}
