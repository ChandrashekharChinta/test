package com.noteflow.dto.auth;

import com.noteflow.dto.user.UserResponse;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class AuthResponse {

    private String token;

    private UserResponse user;
}
