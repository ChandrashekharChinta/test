import { Link, useLocation } from 'react-router-dom'

const links = [
  { to: '/dashboard', label: 'All Notes', icon: '📋' },
  { to: '/dashboard?status=draft', label: 'Drafts', icon: '✏️' },
  { to: '/dashboard?status=published', label: 'Published', icon: '🌐' },
  { to: '/editor/new', label: 'New Note', icon: '➕' },
  { to: '/profile', label: 'Profile', icon: '👤' },
]

export default function Sidebar() {
  const { pathname, search } = useLocation()
  const current = pathname + search

  return (
    <aside className="hidden lg:flex flex-col w-56 shrink-0 border-r border-gray-200 bg-white min-h-screen py-6 px-3">
      <p className="px-3 mb-2 text-xs font-semibold uppercase tracking-wider text-gray-400">Menu</p>
      <nav className="space-y-0.5">
        {links.map((l) => {
          const active = current === l.to || (l.to !== '/dashboard' && pathname.startsWith(l.to))
          return (
            <Link
              key={l.to}
              to={l.to}
              className={`flex items-center gap-3 rounded-lg px-3 py-2 text-sm font-medium transition ${
                active
                  ? 'bg-brand-50 text-brand-700'
                  : 'text-gray-600 hover:bg-gray-100 hover:text-gray-900'
              }`}
            >
              <span className="text-base">{l.icon}</span>
              {l.label}
            </Link>
          )
        })}
      </nav>
    </aside>
  )
}
